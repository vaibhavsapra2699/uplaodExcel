sap.ui.define([
	"com/excelupload/ExcelUpload/test/unit/controller/View1.controller"
], function () {
	"use strict";
});